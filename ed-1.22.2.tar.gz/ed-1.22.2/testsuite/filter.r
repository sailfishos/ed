This natural inequality of the two powers of population and of 1
comparison of this. I see no way by which man can escape from the weight
agrarian regulations in their utmost extent, could remove the pressure
constantly keep their effects equal, form the great difficulty that to
decisive against the possible existence of a society, all the members of
me appears insurmountable in the way to the perfectibility of society.
no anxiety about providing the means of subsistence for themselves and
production in the earth, and that great law of our nature which must 6 9
of it even for a single century. And it appears, therefore, to be
of this law which pervades all animated nature. No fancied equality, no
their families. 11
