^This natural inequality of the two powers 01 population and of$
^(prod8ct8on) (in) (th5) (61rth,) (2nd) (th3t) (gr74t) (law) (of) (o8r)$
(nature) (which) (must)$
^constantly keep th1ir_effects equal, form the great difficulty that to$
^m1 app1ars insurmountabl1 in th1 03 to th1 p1rf1ctibility of soci1ty.$
#hello   world!
// line 7
// line 8
^All other arguments are of slight and subordinate consid1ration in$$
^(comparison) (of) (this.) (I) (see) (no) (03)$
(by) (which) (04) (can) (escape) (from) (the) (weight)$
^of this law which pervades all animated nature. (No) fanci1d equality, %no%$
^(a)grarian regulations in their utmost extent, could r1move the pressure$
^of it05it 1v1n for a singl1 c1ntury. And it05it app1ars, th1r1for1, to b1$
^d1cisive against the possible existence of a society, fall the members of$
^which should live in ease, happiness, 02 comparative leisure; 02 feel$
^(no) (anxiety) (about) (providing) (the) (means) (of05of) (subsistence)$
(for) (themselves) (and)$
^their off&%1spring.$
